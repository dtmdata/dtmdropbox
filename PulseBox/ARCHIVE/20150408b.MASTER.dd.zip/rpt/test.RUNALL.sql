@test.sp_GetDeptsSubordToEmpID.sql
@test.sp_GetIndustryForCompany.sql
@test.sp_GetLocsSubordToEmpID.sql
@test.sp_GetCompanyEvents.sql

@test.sp_parse_id_list.sql

@test.sp_pulse_attrition.sql
@test.sp_pulse_company.sql
@test.sp_pulse_depts.sql
@test.sp_pulse_industry.sql
@test.sp_pulse_locations.sql
@test.sp_pulse_pct_participation.sql

