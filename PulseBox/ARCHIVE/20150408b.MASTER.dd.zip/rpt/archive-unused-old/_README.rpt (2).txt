Reports are designed and based off of the initial .PPTX prototype and text therein.
Each report will have it's own .sql.
Parameter-driven where possible/relevant.
